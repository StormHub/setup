namespace Simulator;

public interface IInstruction
{
}
