using Simulator.Robots;

namespace Simulator.Instructions;

internal interface IInstructionContext
{
    void WriteOutput(string message);
}

internal interface IInstruction
{
    bool Execute(IInstructionContext context, Robot robot);
}
