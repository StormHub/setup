using System.Diagnostics.CodeAnalysis;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Simulator.Robots;

namespace Simulator.Instructions;

internal sealed class InputParser(ILogger<InputParser>? logger)
{
    private readonly ILogger<InputParser> _logger = logger ?? NullLogger<InputParser>.Instance;

    public bool TryParse(string input, [NotNullWhen(true)] out IInstruction? instruction)
    {
        instruction = null;
        
        if (string.IsNullOrWhiteSpace(input))
            return false;

        var trimmed = input.Trim();
        var spaceIndex = trimmed.IndexOf(' ');
        var name = (spaceIndex == -1 ? trimmed : trimmed[..spaceIndex]).ToUpperInvariant();
        var arguments = spaceIndex == -1 ? null : trimmed[(spaceIndex + 1)..];

        instruction = name switch
        {
            "PLACE" when arguments is not null => ParsePlaceCommand(arguments),
            "MOVE" => new MoveCommand(),
            "LEFT" => new LeftCommand(),
            "RIGHT" => new RightCommand(),
            "REPORT" => new ReportQuery(),
            _ => null
        };

        if (instruction is null)
        {
            _logger.LogDebug("Invalid instruction {Input}", input);
            return false;
        }

        return true;
    }

    private static IInstruction? ParsePlaceCommand(string arguments)
    {
        var args = arguments.Split(',', StringSplitOptions.TrimEntries);

        if (args.Length is < 2 or > 3)
            return null;

        if (!int.TryParse(args[0], out var x) || !int.TryParse(args[1], out var y))
            return null;

        if (args.Length == 3)
        {
            return !Direction.TryParse(args[2], out var direction) 
                ? null 
                : new PlaceCommand(x, y, direction);
        }

        return new PlaceCommand(x, y, null);
    }
}
