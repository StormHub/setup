using Simulator.Robots;

namespace Simulator.Instructions;

internal record LeftCommand : IInstruction
{
    public bool Execute(IInstructionContext context, Robot robot) => robot.TryTurnLeft();
}
