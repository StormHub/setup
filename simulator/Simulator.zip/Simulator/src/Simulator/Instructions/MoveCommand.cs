using Simulator.Robots;

namespace Simulator.Instructions;

internal record MoveCommand : IInstruction
{
    public bool Execute(IInstructionContext context, Robot robot) => robot.TryMove();
}
