using Simulator.Robots;

namespace Simulator.Instructions;

internal record PlaceCommand : IInstruction
{
    internal int X { get; }

    internal int Y { get; }

    internal Direction? Direction { get; }

    public PlaceCommand(int x, int y, Direction? direction)
    {
        X = x;
        Y = y;
        Direction = direction;
    }
    
    public bool Execute(IInstructionContext context, Robot robot) => Direction is not null
        ? robot.TryPlace(X, Y, Direction)
        : robot.TryPlace(X, Y);
}
