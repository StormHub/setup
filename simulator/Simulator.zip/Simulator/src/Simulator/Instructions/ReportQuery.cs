using Simulator.Robots;

namespace Simulator.Instructions;

internal sealed class ReportQuery : IInstruction
{
    public bool Execute(IInstructionContext context, Robot robot)
    {
        if (!robot.IsPlaced)
        {
            return false;
        }
        
        context.WriteOutput(robot.Report());
        return true;
    }
}
