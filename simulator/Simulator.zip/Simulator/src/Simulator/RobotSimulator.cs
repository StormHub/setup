using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Simulator.Instructions;
using Simulator.Robots;

namespace Simulator;

internal sealed class RobotSimulator(InputParser parser, ILogger<RobotSimulator>? logger = null)
{
    private readonly Robot _robot = new(new Table());
    private readonly ILogger _logger = logger ?? NullLogger<RobotSimulator>.Instance;

    public void Run(InputReader input, IInstructionContext context, CancellationToken token = default)
    {
        foreach (var line in input.ReadLines(token))
        {
            if (parser.TryParse(line, out var instruction))
            {
                Execute(context, instruction);
            }
        }
    }

    internal void Execute(IInstructionContext context, params IInstruction[] instructions)
    {
        foreach (var instruction in instructions)
        {
            if (!instruction.Execute(context, _robot))
            {
                _logger.LogDebug("Instruction {Instruction} ignored, robot {Robot}",
                    instruction.GetType().Name, _robot.IsPlaced ? _robot.Report() : "not placed");
            }
        }
    }

    internal string Report() => _robot.Report();
}
