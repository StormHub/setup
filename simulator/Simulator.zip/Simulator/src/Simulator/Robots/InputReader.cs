namespace Simulator.Robots;

internal sealed class InputReader(TextReader input)
{
    public IEnumerable<string> ReadLines(CancellationToken token = default)
    {
        while (!token.IsCancellationRequested)
        {
            var line = input.ReadLine();
            if (line == null) break;

            if (string.IsNullOrWhiteSpace(line))
                continue;

            yield return line;
        }
    }
}
