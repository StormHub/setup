using Simulator.Instructions;

namespace Simulator.Robots;

internal sealed class InstructionContext(TextWriter output) : IInstructionContext
{
    public void WriteOutput(string message) => output.WriteLine(message);
}
