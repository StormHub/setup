using System.Diagnostics.CodeAnalysis;

namespace Simulator.Robots;

internal sealed class Table
{
    private const int DefaultSize = 6;

    internal int Size { get; }

    public Table(int size = DefaultSize)
    {
        ArgumentOutOfRangeException.ThrowIfNegativeOrZero(size);
        Size = size;
    }
    
    internal sealed class Position
    {
        public int X { get; }
        
        public int Y { get; }

        private Position(int x, int y)
        {
            X = x;
            Y = y;
        }

        internal static bool TryPlace(Table table, int x, int y, [NotNullWhen(true)] out Position? position)
        {
            position = table.CanPlace(x, y) ? new Position(x, y) : null;
            return position is not null;
        }
    }

    public bool TryPlace(int x, int y, [NotNullWhen(true)] out Position? position) => 
        Position.TryPlace(this, x, y, out position);
    
    private bool CanPlace(int x, int y) => x >= 0 && x < Size && y >= 0 && y < Size;
}
