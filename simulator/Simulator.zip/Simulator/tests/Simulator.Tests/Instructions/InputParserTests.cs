using Simulator.Instructions;
using Simulator.Robots;

namespace Simulator.Tests.Instructions;

public sealed class InputParserTests
{
    private readonly InputParser _parser = new(null);

    [Theory]
    [InlineData("PLACE 1,2,NORTH", 1, 2, "NORTH")]
    [InlineData("place 3,4,west", 3, 4, "WEST")]
    [InlineData("Place 5,6,South", 5, 6, "SOUTH")]
    [InlineData("PLACE 7,8", 7, 8, null)]
    [InlineData("  PLACE 1, 2, NORTH  ", 1, 2, "NORTH")]
    [InlineData("PLACE 1 , 2 , NORTH", 1, 2, "NORTH")]
    [InlineData("PLACE   1,  2,  NORTH", 1, 2, "NORTH")]
    public void TryParse_ValidPlaceCommands(string input, int expectedX, int expectedY, string? directionName)
    {
        var result = _parser.TryParse(input, out var instruction);

        Assert.True(result);
        var placeCommand = Assert.IsType<PlaceCommand>(instruction);
        Assert.Equal(expectedX, placeCommand.X);
        Assert.Equal(expectedY, placeCommand.Y);

        if (directionName is null)
        {
            Assert.Null(placeCommand.Direction);
        }
        else
        {
            Assert.True(Direction.TryParse(directionName, out var direction));
            Assert.Equal(direction, placeCommand.Direction);
        }
    }

    [Theory]
    [InlineData("MOVE", typeof(MoveCommand))]
    [InlineData("move", typeof(MoveCommand))]
    [InlineData("  MOVE  ", typeof(MoveCommand))]
    [InlineData("LEFT", typeof(LeftCommand))]
    [InlineData("left", typeof(LeftCommand))]
    [InlineData("RIGHT", typeof(RightCommand))]
    [InlineData("RIGHT   ", typeof(RightCommand))]
    [InlineData("REPORT", typeof(ReportQuery))]
    [InlineData("report", typeof(ReportQuery))]
    [InlineData("  REPORT  ", typeof(ReportQuery))]
    public void TryParse_ValidNonPlaceCommands(string input, Type expectedType)
    {
        var result = _parser.TryParse(input, out var instruction);

        Assert.True(result);
        Assert.NotNull(instruction);
        Assert.IsType(expectedType, instruction);
    }

    [Theory]
    [InlineData("INVALID")]
    [InlineData("")]
    [InlineData("   ")]
    [InlineData("PLACE")]
    [InlineData("PLACE 1")]
    [InlineData("PLACE 1,2,3,4")]
    [InlineData("PLACE a,b,NORTH")]
    [InlineData("PLACE 1,2,INVALID")]
    [InlineData("PLACE 1,2,")]
    [InlineData("PLACE 1,2, ")]
    [InlineData("MOVE with extra")]
    [InlineData("LEFT foo")]
    [InlineData("RIGHT 123")]
    [InlineData("REPORT anything")]
    public void TryParse_InvalidInputs_ReturnsFalseAndNull(string input)
    {
        var result = _parser.TryParse(input, out var instruction);

        Assert.False(result);
        Assert.Null(instruction);
    }
}
