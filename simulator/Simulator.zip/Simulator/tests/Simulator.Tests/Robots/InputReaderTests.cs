using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class InputReaderTests
{
    [Fact]
    public void ReadLines_WithSingleLine_ReturnsSingleLine()
    {
        var input = new StringReader("PLACE 0,0,NORTH");
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Single(lines);
        Assert.Equal("PLACE 0,0,NORTH", lines[0]);
    }

    [Fact]
    public void ReadLines_WithMultipleLines_ReturnsAllLines()
    {
        var inputText = """
            PLACE 0,0,NORTH
            MOVE
            REPORT
            """;
        var input = new StringReader(inputText);
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Collection(lines,
            line => Assert.Equal("PLACE 0,0,NORTH", line),
            line => Assert.Equal("MOVE", line),
            line => Assert.Equal("REPORT", line));
    }

    [Fact]
    public void ReadLines_WithEmptyLines_SkipsEmptyLines()
    {
        var inputText = """
            PLACE 0,0,NORTH

            MOVE

            REPORT
            """;
        var input = new StringReader(inputText);
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Collection(lines,
            line => Assert.Equal("PLACE 0,0,NORTH", line),
            line => Assert.Equal("MOVE", line),
            line => Assert.Equal("REPORT", line));
    }

    [Fact]
    public void ReadLines_WithWhitespaceOnlyLines_SkipsWhitespaceLines()
    {
        var inputText = "PLACE 0,0,NORTH\n   \nMOVE\n\t\nREPORT";
        var input = new StringReader(inputText);
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Collection(lines,
            line => Assert.Equal("PLACE 0,0,NORTH", line),
            line => Assert.Equal("MOVE", line),
            line => Assert.Equal("REPORT", line));
    }

    [Fact]
    public void ReadLines_WithEmptyInput_ReturnsEmptySequence()
    {
        var input = new StringReader(string.Empty);
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Empty(lines);
    }

    [Fact]
    public void ReadLines_WithMixedContent_PreservesLineContent()
    {
        var inputText = "PLACE 0,0,NORTH\nMOVE  \n  LEFT\nREPORT";
        var input = new StringReader(inputText);
        var reader = new InputReader(input);

        var lines = reader.ReadLines().ToList();

        Assert.Collection(lines,
            line => Assert.Equal("PLACE 0,0,NORTH", line),
            line => Assert.Equal("MOVE  ", line),
            line => Assert.Equal("  LEFT", line),
            line => Assert.Equal("REPORT", line));
    }

    [Fact]
    public void ReadLines_CancelsDuringEnumeration()
    {
        var input = new StringReader("PLACE 0,0,NORTH\nMOVE\nREPORT");
        var reader = new InputReader(input);
        var lines = new List<string>();

        using var cts = new CancellationTokenSource();
        foreach (var line in reader.ReadLines(cts.Token))
        {
            lines.Add(line);
            cts.Cancel();
        }

        Assert.Collection(lines,
            line => Assert.Equal("PLACE 0,0,NORTH", line));
    }
}
