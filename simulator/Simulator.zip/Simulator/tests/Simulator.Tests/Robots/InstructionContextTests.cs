using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class InstructionContextTests
{
    [Fact]
    public void WriteOutput_WithSingleMessage_WritesToOutput()
    {
        var output = new StringWriter();
        var context = new InstructionContext(output);

        context.WriteOutput("0,0,NORTH");

        var outputText = output.ToString();
        Assert.Equal("0,0,NORTH" + Environment.NewLine, outputText);
    }

    [Fact]
    public void WriteOutput_WithMultipleMessages_WritesAllMessages()
    {
        var output = new StringWriter();
        var context = new InstructionContext(output);

        context.WriteOutput("First message");
        context.WriteOutput("Second message");
        context.WriteOutput("Third message");

        var outputText = output.ToString();
        var expectedOutput = 
            "First message" + Environment.NewLine +
            "Second message" + Environment.NewLine +
            "Third message" + Environment.NewLine;
        Assert.Equal(expectedOutput, outputText);
    }

    [Fact]
    public void WriteOutput_WithEmptyString_WritesEmptyLine()
    {
        var output = new StringWriter();
        var context = new InstructionContext(output);

        context.WriteOutput(string.Empty);

        var outputText = output.ToString();
        Assert.Equal(Environment.NewLine, outputText);
    }
}
