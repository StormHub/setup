using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class InstructionContextTests
{
    [Fact]
    public void WriteOutput_WithSingleMessage_WritesToOutput()
    {
        // Arrange
        var output = new StringWriter();
        var context = new InstructionContext(output);

        // Act
        context.WriteOutput("0,0,NORTH");

        // Assert
        var outputText = output.ToString();
        Assert.Equal("0,0,NORTH" + Environment.NewLine, outputText);
    }

    [Fact]
    public void WriteOutput_WithMultipleMessages_WritesAllMessages()
    {
        // Arrange
        var output = new StringWriter();
        var context = new InstructionContext(output);

        // Act
        context.WriteOutput("First message");
        context.WriteOutput("Second message");
        context.WriteOutput("Third message");

        // Assert
        var outputText = output.ToString();
        var expectedOutput = "First message" + Environment.NewLine +
                           "Second message" + Environment.NewLine +
                           "Third message" + Environment.NewLine;
        Assert.Equal(expectedOutput, outputText);
    }

    [Fact]
    public void WriteOutput_WithEmptyString_WritesEmptyLine()
    {
        // Arrange
        var output = new StringWriter();
        var context = new InstructionContext(output);

        // Act
        context.WriteOutput(string.Empty);

        // Assert
        var outputText = output.ToString();
        Assert.Equal(Environment.NewLine, outputText);
    }

    [Fact]
    public void Constructor_WithValidParameters_CreatesInstance()
    {
        // Arrange
        var output = new StringWriter();

        // Act
        var context = new InstructionContext(output);

        // Assert
        Assert.NotNull(context);
    }
}
