using Simulator.Instructions;
using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class RobotSimulatorTests : IInstructionContext
{
    private readonly RobotSimulator _simulator;
    private readonly StringWriter _output;

    public RobotSimulatorTests()
    {
        _simulator = new(new InputParser(null));
        _output = new StringWriter();
    }
    
    void IInstructionContext.WriteOutput(string message) => _output.Write(message);

    [Fact]
    public void PlaceMoveReport_OutputsCorrectPosition()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(0, 0, Direction.North),
            new MoveCommand());

        // Assert
        Assert.Equal("0,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void PlaceLeftReport_OutputsCorrectPosition()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(0, 0, Direction.North),
            new LeftCommand());

        // Assert
        Assert.Equal("0,0,WEST", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void ComplexMovementSequence_OutputsCorrectPosition()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(1, 2, Direction.East),
            new MoveCommand(),
            new MoveCommand(),
            new LeftCommand(),
            new MoveCommand());

        // Assert
        Assert.Equal("3,3,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void PlaceWithoutDirection_OutputsCorrectPosition()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(1, 2, Direction.East),
            new MoveCommand(),
            new LeftCommand(),
            new MoveCommand(),
            new PlaceCommand(3, 1, null),
            new MoveCommand());

        // Assert
        Assert.Equal("3,2,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void CommandsBeforeFirstPlace_AreIgnored()
    {
        // Act
        _simulator.Execute(
            this,
            new MoveCommand(),
            new LeftCommand(),
            new RightCommand(),
            new PlaceCommand(1, 1, Direction.North));

        // Assert
        Assert.Equal("1,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void InvalidPlaceCommand_DoesNotPlaceRobot()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(6, 6, Direction.North),
            new PlaceCommand(1, 1, Direction.North));

        // Assert
        Assert.Equal("1,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void MovePreventingFall_DoesNotMoveRobot()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(0, 0, Direction.South),
            new MoveCommand());

        // Assert
        Assert.Equal("0,0,SOUTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void MultipleReports_OutputMultipleTimes()
    {
        // Act
        _simulator.Execute(this, new PlaceCommand(0, 0, Direction.North));
        var output1 = _simulator.Report();
        
        _simulator.Execute(this, new MoveCommand());
        var output2 = _simulator.Report();

        // Assert
        Assert.Equal("0,0,NORTH", output1);
        Assert.Equal("0,1,NORTH", output2);
        Assert.Empty(_output.ToString());
    }

    [Theory]
    [InlineData(0, 0)]
    [InlineData(5, 5)]
    [InlineData(0, 5)]
    [InlineData(5, 0)]
    public void PlaceAtCorners_WorksCorrectly(int x, int y)
    {
        // Act
        _simulator.Execute(this, new PlaceCommand(x, y, Direction.North));

        // Assert
        Assert.Equal($"{x},{y},NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void RobotMovingAlongEdges_DoesNotFall()
    {
        // Act - Move along north edge
        _simulator.Execute(
            this,
            new PlaceCommand(0, 5, Direction.East),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand());

        // Assert
        Assert.Equal("5,5,EAST", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void RotationsOnly_DoNotChangePosition()
    {
        // Act - Four right turns = full rotation
        _simulator.Execute(
            this,
            new PlaceCommand(2, 2, Direction.North),
            new RightCommand(),
            new RightCommand(),
            new RightCommand(),
            new RightCommand());

        // Assert
        Assert.Equal("2,2,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void ReportCommand_WritesToOutput()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(1, 2, Direction.East),
            new ReportQuery());

        // Assert
        Assert.Equal("1,2,EAST", _output.ToString());
    }

    [Fact]
    public void MultipleReportCommands_WriteMultipleOutputs()
    {
        // Act
        _simulator.Execute(
            this,
            new PlaceCommand(0, 0, Direction.North),
            new ReportQuery(),
            new MoveCommand(),
            new ReportQuery(),
            new MoveCommand(),
            new ReportQuery());

        // Assert
        Assert.Equal("0,0,NORTH0,1,NORTH0,2,NORTH", _output.ToString());
    }

    [Fact]
    public void ReportBeforePlacement_DoesNotWriteOutput()
    {
        // Act
        _simulator.Execute(
            this,
            new ReportQuery(),
            new PlaceCommand(1, 1, Direction.South),
            new ReportQuery());

        // Assert
        Assert.Equal("1,1,SOUTH", _output.ToString());
    }
}
