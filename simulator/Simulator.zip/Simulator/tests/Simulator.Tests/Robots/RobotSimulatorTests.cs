using Simulator.Instructions;
using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class RobotSimulatorTests
{
    private readonly RobotSimulator _simulator;
    private readonly IInstructionContext _context;
    private readonly StringWriter _output;

    public RobotSimulatorTests()
    {
        _simulator = new(new InputParser(null));
        _output = new StringWriter();
        _context = new InstructionContext(_output);
    }

    [Fact]
    public void PlaceMoveReport_OutputsCorrectPosition()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(0, 0, Direction.North),
            new MoveCommand());

        Assert.Equal("0,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void PlaceLeftReport_OutputsCorrectPosition()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(0, 0, Direction.North),
            new LeftCommand());

        Assert.Equal("0,0,WEST", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void ComplexMovementSequence_OutputsCorrectPosition()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(1, 2, Direction.East),
            new MoveCommand(),
            new MoveCommand(),
            new LeftCommand(),
            new MoveCommand());

        Assert.Equal("3,3,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void PlaceWithoutDirection_OutputsCorrectPosition()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(1, 2, Direction.East),
            new MoveCommand(),
            new LeftCommand(),
            new MoveCommand(),
            new PlaceCommand(3, 1, null),
            new MoveCommand());

        Assert.Equal("3,2,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void CommandsBeforeFirstPlace_AreIgnored()
    {
        _simulator.Execute(
            _context,
            new MoveCommand(),
            new LeftCommand(),
            new RightCommand(),
            new PlaceCommand(1, 1, Direction.North));

        Assert.Equal("1,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void InvalidPlaceCommand_DoesNotPlaceRobot()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(6, 6, Direction.North),
            new PlaceCommand(1, 1, Direction.North));

        Assert.Equal("1,1,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void MovePreventingFall_DoesNotMoveRobot()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(0, 0, Direction.South),
            new MoveCommand());

        Assert.Equal("0,0,SOUTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void MultipleReports_OutputMultipleTimes()
    {
        _simulator.Execute(_context, new PlaceCommand(0, 0, Direction.North));
        var output1 = _simulator.Report();
        
        _simulator.Execute(_context, new MoveCommand());
        var output2 = _simulator.Report();

        Assert.Equal("0,0,NORTH", output1);
        Assert.Equal("0,1,NORTH", output2);
        Assert.Empty(_output.ToString());
    }

    [Theory]
    [InlineData(0, 0)]
    [InlineData(5, 5)]
    [InlineData(0, 5)]
    [InlineData(5, 0)]
    public void PlaceAtCorners_WorksCorrectly(int x, int y)
    {
        _simulator.Execute(_context, new PlaceCommand(x, y, Direction.North));

        Assert.Equal($"{x},{y},NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void RobotMovingAlongEdges_DoesNotFall()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(0, 5, Direction.East),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand(),
            new MoveCommand());

        Assert.Equal("5,5,EAST", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void RotationsOnly_DoNotChangePosition()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(2, 2, Direction.North),
            new RightCommand(),
            new RightCommand(),
            new RightCommand(),
            new RightCommand());

        Assert.Equal("2,2,NORTH", _simulator.Report());
        Assert.Empty(_output.ToString());
    }

    [Fact]
    public void ReportCommand_WritesToOutput()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(1, 2, Direction.East),
            new ReportQuery());

        Assert.Equal("1,2,EAST\n", _output.ToString());
    }

    [Fact]
    public void MultipleReportCommands_WriteMultipleOutputs()
    {
        _simulator.Execute(
            _context,
            new PlaceCommand(0, 0, Direction.North),
            new ReportQuery(),
            new MoveCommand(),
            new ReportQuery(),
            new MoveCommand(),
            new ReportQuery());

        Assert.Equal("0,0,NORTH\n0,1,NORTH\n0,2,NORTH\n", _output.ToString());
    }

    [Fact]
    public void ReportBeforePlacement_DoesNotWriteOutput()
    {
        _simulator.Execute(
            _context,
            new ReportQuery(),
            new PlaceCommand(1, 1, Direction.South),
            new ReportQuery());

        Assert.Equal("1,1,SOUTH\n", _output.ToString());
    }
}
