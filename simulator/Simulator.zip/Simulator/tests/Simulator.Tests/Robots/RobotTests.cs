using Simulator.Robots;

namespace Simulator.Tests.Robots;

public sealed class RobotTests
{
    private readonly Robot _robot;
    
    public RobotTests()
    {
        var table = new Table();
        _robot = new Robot(table);
    }
    
    [Fact]
    public void Robot_InitialState_IsNotPlaced()
    {
        Assert.False(_robot.IsPlaced);
        Assert.Equal(string.Empty, _robot.Report());
    }

    [Fact]
    public void Place_WithValidPositionAndDirection_PlacesRobot()
    {
        var result = _robot.TryPlace(1, 2, Direction.North);

        Assert.True(result);
        Assert.True(_robot.IsPlaced);
        Assert.Equal("1,2,NORTH", _robot.Report());
    }

    [Theory]
    [InlineData(-1, 0)]
    [InlineData(0, -1)]
    [InlineData(6, 0)]
    [InlineData(0, 6)]
    public void Place_WithInvalidPosition_DoesNotPlaceRobot(int x, int y)
    {
        var result = _robot.TryPlace(x, y, Direction.North);

        Assert.False(result);
        Assert.False(_robot.IsPlaced);
    }

    [Fact]
    public void Place_WithPositionOnly_WhenNotPlaced_DoesNotPlaceRobot()
    {
        var result = _robot.TryPlace(1, 1);

        Assert.False(result);
        Assert.False(_robot.IsPlaced);
    }

    [Fact]
    public void Place_WithPositionOnly_WhenPlaced_MovesRobotWithoutChangingDirection()
    {
        _robot.TryPlace(0, 0, Direction.North);

        var result = _robot.TryPlace(3, 3);

        Assert.True(result);
        Assert.Equal("3,3,NORTH", _robot.Report());
    }

    [Fact]
    public void Move_WhenNotPlaced_ReturnsFalse()
    {
        var result = _robot.TryMove();

        Assert.False(result);
    }

    public static TheoryData<int, int, Direction, string> MoveInDirectionData =>
        new()
        {
            { 0, 0, Direction.North, "0,1,NORTH" },
            { 0, 0, Direction.East, "1,0,EAST" },
            { 5, 5, Direction.South, "5,4,SOUTH" },
            { 5, 5, Direction.West, "4,5,WEST" }
        };

    [Theory]
    [MemberData(nameof(MoveInDirectionData))]
    public void Move_InDirection_MovesRobotCorrectly(int x, int y, Direction direction, string expected)
    {
        _robot.TryPlace(x, y, direction);

        var result = _robot.TryMove();

        Assert.True(result);
        Assert.Equal(expected, _robot.Report());
    }

    public static TheoryData<int, int, Direction> MoveWouldFallOffTableData =>
        new()
        {
            { 0, 0, Direction.South },
            { 0, 0, Direction.West },
            { 5, 5, Direction.North },
            { 5, 5, Direction.East }
        };

    [Theory]
    [MemberData(nameof(MoveWouldFallOffTableData))]
    public void Move_WouldFallOffTable_DoesNotMove(int x, int y, Direction direction)
    {
        _robot.TryPlace(x, y, direction);
        var originalReport = _robot.Report();

        var result = _robot.TryMove();

        Assert.False(result);
        Assert.Equal(originalReport, _robot.Report());
    }

    [Fact]
    public void Left_WhenNotPlaced_ReturnsFalse()
    {
        var result = _robot.TryTurnLeft();

        // Assert
        Assert.False(result);
    }

    public static TheoryData<Direction, string> LeftRotatesCounterClockwiseData =>
        new()
        {
            { Direction.North, "0,0,WEST" },
            { Direction.West, "0,0,SOUTH" },
            { Direction.South, "0,0,EAST" },
            { Direction.East, "0,0,NORTH" }
        };

    [Theory]
    [MemberData(nameof(LeftRotatesCounterClockwiseData))]
    public void Left_RotatesRobotCounterClockwise(Direction initialDirection, string expected)
    {
        _robot.TryPlace(0, 0, initialDirection);

        var result = _robot.TryTurnLeft();

        Assert.True(result);
        Assert.Equal(expected, _robot.Report());
    }

    [Fact]
    public void Right_WhenNotPlaced_ReturnsFalse()
    {
        var result = _robot.TryTurnRight();

        Assert.False(result);
    }

    public static TheoryData<Direction, string> RightRotatesClockwiseData =>
        new()
        {
            { Direction.North, "0,0,EAST" },
            { Direction.East, "0,0,SOUTH" },
            { Direction.South, "0,0,WEST" },
            { Direction.West, "0,0,NORTH" }
        };

    [Theory]
    [MemberData(nameof(RightRotatesClockwiseData))]
    public void Right_RotatesRobotClockwise(Direction initialDirection, string expected)
    {
        _robot.TryPlace(0, 0, initialDirection);

        var result = _robot.TryTurnRight();

        Assert.True(result);
        Assert.Equal(expected, _robot.Report());
    }

    [Fact]
    public void Report_WhenNotPlaced_ReturnsEmptyString()
    {
        var result = _robot.Report();

        Assert.Equal(string.Empty, result);
    }

    [Fact]
    public void Report_WhenPlaced_ReturnsCorrectFormat()
    {
        _robot.TryPlace(3, 4, Direction.South);

        var result = _robot.Report();

        Assert.Equal("3,4,SOUTH", result);
    }
}
